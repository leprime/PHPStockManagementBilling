function adduser()
{
	//$( "#btn2" ).click(function() {
		 	 	$("#useradd" ).show( 1800 );
		 	 	$("#password").hide("fast");
		 	 	$("#delete").hide("fast");
		//		});
}
function password()
{
	//$( "#btn2" ).click(function() {
		 	 	$("#password" ).show( 1800 );
		 	 	$("#useradd").hide("fast");
		 	 	$("#delete").hide("fast");
		//		});
}
function deleteuser()
{
	//$( "#btn2" ).click(function() {
		 	 	$("#delete" ).show( 1800 );
		 	 	$("#password").hide("fast");
		 	 	$("#useradd").hide("fast");
		//		});
}