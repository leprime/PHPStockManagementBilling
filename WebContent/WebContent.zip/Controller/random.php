<?php 

	echo date("Y/m/d").substr( md5(rand()), 0, 4);

?>